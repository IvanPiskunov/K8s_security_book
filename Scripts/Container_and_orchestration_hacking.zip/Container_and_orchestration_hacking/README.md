# Harpoon

```
    __  __                                 
   / / / /___ __________  ____  ____  ____ 
  / /_/ / __ `/ ___/ __ \/ __ \/ __ \/ __ \
 / __  / /_/ / /  / /_/ / /_/ / /_/ / / / /
/_/ /_/\__,_/_/  / .___/\____/\____/_/ /_/ 
                /_/       ,   ,
    ~~~~~~~~~~~~~~~~~~~~~~~"o"~~~~
            ____________     o
    	 _--            --_ o
        /       ___      __\ o
       / _         _\    \__o 
      / / |              X  |
     / /   \	           /
    / _ \   \             /
    \/ \/    -.____ ____.-
```

## A collection of tips and tricks for container and container orchestration hacking.

*TODO: write documentation*
