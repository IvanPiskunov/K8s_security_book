#!/bin/bash
# look for the docker socket if it was mounted.
find "/" -name docker.sock 2>&1  
