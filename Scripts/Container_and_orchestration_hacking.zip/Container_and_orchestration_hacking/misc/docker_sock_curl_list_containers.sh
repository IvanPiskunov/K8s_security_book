curl -s -XGET --unix-socket $DOCKER_SOCK_PATH http://localhost/containers/json 2>&1
