# Examples

This examples are to help give a basic overview of what a repository using `rok8-scripts` might look like.

Click on any example to learn more about it.
