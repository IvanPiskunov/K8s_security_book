This example demonstrates how to use rok8s-scripts with four different CI platforms:
- [Bitbucket Pipelines](/examples/ci/bitbucket-pipelines.yml)
- [CircleCI](/examples/ci/.circleci/config.yml)
- [GitLab CI](/examples/ci/.gitlab-ci.yml)
- [Jenkins](/examples/ci/Jenkinsfile)
