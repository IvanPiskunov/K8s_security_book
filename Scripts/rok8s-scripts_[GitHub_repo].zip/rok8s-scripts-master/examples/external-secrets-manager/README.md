# external-secrets-manager example

**Note:** this example uses CircleCI v1

This example shows how to use rok8s-scripts with an external secrets manager
