# rok8s-scripts Roadmap

## Q32019
Below is a list of work we plan to get done this quarter. Some more details can be found under
[the milestone](https://github.com/FairwindsOps/rok8s-scripts/milestone/3).

* Create a CircleCI Orb
* Expand documentation and examples, update CircleCI examples to v2
* End-to-end testing (stretch goal)
* Remove ci-images (stretch goal)
* Deprecate old features (stretch goal)
