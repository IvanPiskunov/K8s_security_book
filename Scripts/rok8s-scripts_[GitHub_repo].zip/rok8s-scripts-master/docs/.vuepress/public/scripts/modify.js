/*
 * This file is generated from FairwindsOps/documentation-template
 * DO NOT EDIT MANUALLY
 */

document.addEventListener("DOMContentLoaded", function(){
  setTimeout(function() {
    var link = document.getElementsByClassName('home-link')[0];
    linkClone = link.cloneNode(true);
    linkClone.href = "https://fairwinds.com";
    link.setAttribute('target', '_blank');
    link.parentNode.replaceChild(linkClone, link);
  }, 1000);
});

